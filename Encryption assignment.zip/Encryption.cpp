//
//  Encryption.cpp
//  EncryptionApp
//
//  Created by Corey C. H. on 7/22/24.
//

#include "Encryption.hpp"
#include <iostream>
#include <fstream>
#include <string>

// Function to read data from a file into a string
std::string read_file(const std::string& filename) {
    std::ifstream infile(filename);
    if (!infile.is_open()) {
        throw std::runtime_error("Could not open file for reading: " + filename);
    }

    std::string data, line;
    while (std::getline(infile, line)) {
        data += line + '\n';
    }
    infile.close();
    return data;
}

// Function to save data from a string into a file
void save_data_file(const std::string& filename, const std::string& data) {
    std::ofstream outfile(filename);
    if (!outfile.is_open()) {
        throw std::runtime_error("Could not open file for writing: " + filename);
    }

    outfile << data;
    outfile.close();
}

// Function to perform XOR encryption/decryption
std::string xor_encrypt(const std::string& data, const std::string& key) {
    std::string encrypted_data = data;
    for (size_t i = 0; i < data.size(); ++i) {
        encrypted_data[i] = data[i] ^ key[i % key.size()];
    }
    return encrypted_data;
}

int main() {
    try {
        std::string key = "secretkey";
        std::string input_filename = "inputdatafile.txt";
        std::string encrypted_filename = "encrypteddatafile.txt";
        std::string decrypted_filename = "decrypteddatafile.txt";

        // Read the original data
        std::string original_data = read_file(input_filename);
        std::cout << "Original Data:\n" << original_data << "\n";

        // Encrypt the data
        std::string encrypted_data = xor_encrypt(original_data, key);
        save_data_file(encrypted_filename, encrypted_data);
        std::cout << "Data has been encrypted and saved to " << encrypted_filename << "\n";

        // Decrypt the data
        std::string read_encrypted_data = read_file(encrypted_filename);
        std::string decrypted_data = xor_encrypt(read_encrypted_data, key);
        save_data_file(decrypted_filename, decrypted_data);
        std::cout << "Data has been decrypted and saved to " << decrypted_filename << "\n";

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
    }

    return 0;
}
